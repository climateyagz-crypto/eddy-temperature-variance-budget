# 瞬变涡旋温度方差收支方程

根据现存修订脚本整理的四阶段代码与计算说明。默认保留 **2.5—8 日** Lanczos 带通，不能称作严格的 2—8 日带通。原始数据和私人指数不随包公开。

| 阶段 | 内容 | 手动运行命令 |
|---|---|---|
| 1_Q | 日平均温度、风、压力速度诊断 Q₁ | `bash 1_Q/run.sh` |
| 2_bandpass | Q₁、u、v、ω、T 的日序列带通 | `bash 2_bandpass/run.sh` |
| 3_formal_cal | BC、EC、DS、HT、VET、RESI | `bash 3_formal_cal/run.sh` |
| 3_formal_cal 补充 | TT、EKE、v′T′、EGR、BC分解基础量 | `bash 3_formal_cal/run_aux.sh` |
| 4_reg_draw | 跨年季节合成、趋势控制回归、绘图 | `bash 4_reg_draw/run.sh regress`，完成后 `bash 4_reg_draw/run.sh plot` |

`common` 是公共读取与路径函数；每一步完成并核查后再手动启动下一步。没有自动从头执行全流程的入口。

## 配置与环境

1. 计算需要 NCL 及其 contributed.ncl；Python 需要 `python -m pip install -r requirements.txt`。绘图海岸线需要 Cartopy 数据缓存或下载权限。
2. 修改 `config.sh` 的年份。默认 1982—2023，当前带月边界实现支持 1980—2024（假设原始资料覆盖1979—2025）。
3. 修改 `common/paths.ncl` 的原始和派生路径。公开版使用通用目录 `/data/ERA5_4xDaily/` 与 `/data/eddy_temperature_variance_budget/`。**同时修改 `3_formal_cal/*_fixed.ncl` 的独立路径配置和 `4_reg_draw/run0916.sh` 的 budget_root、storm_root**；这些补充脚本保留自包含读取函数。
4. 原始文件命名须符合代码模板，例如 `air/air.6h.global.1deg.1982.01.nc`。u、v、ω目录分别为uwnd、vwnd、wwnd。EGR另需真实位势或高度文件，设置height_template、height_var并核对其单位。
5. 在 `4_reg_draw/run0916.sh` 填入自己的 `INDEX_VALUES`、起止年、位相。公开版指数为空，未填写时会明确报错。默认层次200/850hPa、NDJ/DJF/JFM；需要翌年完整月份。
6. 字体默认要求Arial。自行安装有使用权的字体或设置FONT_FILE；包中不含字体。平滑参数只作用于叠加的平均等值线。

**派生结果允许覆盖**：主NCL文件替换已有输出；失败可能留下不完整文件，需重跑对应阶段。首次使用请指向独立输出目录。原始资料只读。日志保存在logs，运行器遇fatal或缺少完成标记即停止。

## 读取与单位

每月文件独立解包scale_factor/add_offset。兼容time/valid_time和level/pressure_level，规范压力、纬度时同步翻转数据；压力微分用Pa，ω为Pa/s。不能复用一月的packing参数，也不能只改坐标标签。

Q₁保存W/kg，收支保存K²/s；绘图显示乘10⁵。TT为温度方差K²，并非温度方差的时间导数；EKE为m²/s²，v′T′为K·m/s，EGR为s⁻¹（绘图乘86400显示day⁻¹）。

数据产品名称、公式、回归和质量限制见 [计算过程说明.md](计算过程说明.md)。逐文件校验值见SHA256SUMS.txt。

## 版本与验证范围

阶段1—3来自现存四阶段修订代码；补充诊断来自storm_fixed，BC基础量采用后来修正的−1系数版本；阶段4采用run0916修订版，替换早期仅ON/D/J的统计入口。公开整理修改路径、移除私人指数并增加补充入口，保留科学计算核心。

不能确认服务器上未传回的最终修改，也没有原始ERA5数据和NCL运行环境。本版完成Python编译、Bash语法与路径/隐私检查，**不代表完成NCL编译或真实资料重算验证**。残差按定义闭合不能证明五个显式项计算正确。未附原始数据、结果、机器日志、私人路径或字体，也没有连接任何个人电脑的程序。
