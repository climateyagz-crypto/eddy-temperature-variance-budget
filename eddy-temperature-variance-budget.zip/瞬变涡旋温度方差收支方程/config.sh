# NCL 计算年份；数据路径统一见 common/paths.ncl，补充脚本及绘图另见说明。
START_YEAR=${START_YEAR:-1982}
END_YEAR=${END_YEAR:-2023}
