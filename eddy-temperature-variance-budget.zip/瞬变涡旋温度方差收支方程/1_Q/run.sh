#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/../common/run_stage.sh"
run_ncl "1_Q/cal_01_Q1_yanai_0714.ncl"
echo '1_Q 完成。请自行检查，再手动启动下一阶段。'

