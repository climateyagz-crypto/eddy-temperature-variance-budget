#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/../common/run_stage.sh"
run_ncl "2_bandpass/1_cal_Q1_bandpass_lanczos.ncl"
run_ncl "2_bandpass/2_cal_u_bandpass_lanczos.ncl"
run_ncl "2_bandpass/3_cal_v_bandpass_lanczos.ncl"
run_ncl "2_bandpass/4_cal_w_bandpass_lanczos.ncl"
run_ncl "2_bandpass/5_cal_t_bandpass_lanczos.ncl"
echo '2_bandpass 完成。请自行检查，再手动启动下一阶段。'

