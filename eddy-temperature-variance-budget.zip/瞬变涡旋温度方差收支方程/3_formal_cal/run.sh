#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/../common/run_stage.sh"
run_ncl "3_formal_cal/cal_bc_0717.ncl"
run_ncl "3_formal_cal/cal_ec_0717.ncl"
run_ncl "3_formal_cal/cal_ds_0717.ncl"
run_ncl "3_formal_cal/cal_horizontal_transport_0717.ncl"
run_ncl "3_formal_cal/cal_vertical_transport_0717.ncl"
run_ncl "3_formal_cal/cal_resi_0717.ncl"
echo '3_formal_cal 完成。请自行检查，再手动启动下一阶段。'

