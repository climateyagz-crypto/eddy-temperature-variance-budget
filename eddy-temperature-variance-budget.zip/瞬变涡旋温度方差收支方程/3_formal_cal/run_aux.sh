#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "${BASH_SOURCE[0]}")/../common/run_stage.sh"
run_ncl "3_formal_cal/cal_TT_0717_fixed.ncl"
run_ncl "3_formal_cal/cal_EKE-TLLL_fixed.ncl"
run_ncl "3_formal_cal/cal_vT-TLLL_0717_fixed.ncl"
run_ncl "3_formal_cal/cal_EGR-TLLL_fixed.ncl"
run_ncl "3_formal_cal/cal_bc_sep_fixed.ncl"
