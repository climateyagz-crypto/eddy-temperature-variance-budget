#!/usr/bin/env bash
set -euo pipefail
# 用法: bash run0916.sh regress | regress-bc | budget | bc | other | plot
# regress-bc 只重算BC分解(先合成两项再回归)，保留其他统计结果。
# regress 只计算统计量；budget/bc/other 分别画图；plot 画下方启用的图。
# 不重算 Q、滤波、收支或风暴轴。没有自动执行全流程的默认操作。
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${PYTHON:-python}"
OUTPUT="$script_dir/results"
FIGURE_OUTPUT="$script_dir/figures"
mkdir -p "$OUTPUT" "$FIGURE_OUTPUT"
export REG_OUTPUT="$OUTPUT" REG_FIGURES="$FIGURE_OUTPUT"
config_file="$OUTPUT/plot_config.json"
"$PYTHON" - "$config_file" <<'PYCONFIG'
import json,os,sys
# ====================== 所有用户配置集中在这里 ======================
# 每个数依次对应 INDEX_START 至 INDEX_END；请自行提供指数。
INDEX_START=1982
INDEX_END=2022
INDEX_VALUES=[]  # 按年份填入自己的指数；公开版不包含私人研究序列
INDEX_SIGN=1               # 延续上一版全套图位相；你新发的BC脚本取负号，若要一致请设-1并regress全套
LEVELS=[200,850]            # hPa，例如 [500] 或 [250,500,850]
SEASONS=['NDJ','DJF','JFM'] # 分别为 ND(0)J(+1), D(0)JF(+1), JFM(+1)
CALCULATE=['BC','EC','DS','HT','VET','RESI','TT','EKE','VT','EGR','sep_tgr','sep_eddyhflux']
PLOT_BUDGET=True
PLOT_BC=True
PLOT_VARIABLES=['TT','EKE','VT','EGR'] # 可额外选 BC_NONLINEAR / BC_SEP_RESIDUAL / BC_OPERATOR_DIFF 等
PLOT_STATISTICS=['slope']      # 只画回归；若同时画平均场，设 ['slope','mean']
# 论文式(4)：先各自求季节平均，再求季节气候态/异常，构造两项后回归。
BC_MODE='mechanism'         # mechanism:热通量变化/温度梯度变化；direction:东西向/南北向
BC_FACTOR=1.0              # 论文式(4)及已有BC系数均为-1，本版要求此值为1
SEASON_WEIGHT='equal'      # equal:三个月等权；days:按各月实际天数加权，所有变量一致
DAILY_VALID_FRACTION=1.0   # 每月所需有效日比例；1要求全月有效。EGR不稳定日为缺测，不填0
MIN_N=30                   # 每格点至少有效的指数年数
P_METHOD='iid'             # iid 或 hac；两种p值均保存
HAC_LAGS=3
ALPHA=0.1
MEAN_CONTOURS=True          # 回归图叠加多年平均等值线
EXTENT=[120,260,20,70]      # 经度0--360，纬度南--北
DPI=600
COASTLINES=True
FONT_FAMILY='Arial'
FONT_FILE=''               # 若服务器未安装Arial，可填Arial字体文件的绝对路径
FONT_REQUIRED=True        # 找不到指定字体就报错；不静默换字体
MEAN_SMOOTH_SIGMA_DEG=1.0  # 高斯标准差(度)，仅平滑叠加黑线；0关闭
TITLE_SIZE=18
MEAN_CONTOUR_INTERVAL=3.0  # 显示单位下动态画 ±3、±6、±9…，零线永远不画
# 色标中的数字均是物理场乘 multiplier 后的显示值，不影响保存的回归数值。
# regression/mean=[最小值,最大值,间隔]，contours为平均场等值线的显示值。
def style(mult,label,reg,mean,contours,cmap='RdBu_r'):
    return dict(multiplier=mult,label=label,regression=reg,mean=mean,contours=contours,cmap=cmap)
STYLES={
 'DEFAULT':style(1e5,r'$10^{-5}$ K$^2$ s$^{-1}$',[-1.4,1.4,.2],[-30,30,5],[-30,-20,-10,-5,5,10,20,30]),
 'TT':style(1,r'K$^2$',[-1.4,1.4,.2],[0,40,5],[5,10,15,20,25,30]),
 'EKE':style(1,r'm$^2$ s$^{-2}$',[-5,5,1],[0,200,25],[25,50,75,100,150,200]),
 'VT':style(1,r'K m s$^{-1}$',[-1.4,1.4,.2],[-30,30,5],[-20,-10,-5,5,10,20]),
 'EGR':style(86400,r'day$^{-1}$',[-.06,.06,.01],[0,1,.1],[.2,.4,.6,.8]),
}
# EGR保留原来的平均场线值；其量级为day^-1，不能机械套用间隔3。
STYLES['EGR']['contour_interval']=None
# 其他变量默认动态间隔3，覆盖旧contours列表。可逐变量修改contour_interval。
# 单独改任意变量，例如：
# STYLES['VET']=style(1e5,r'$10^{-5}$ K$^2$ s$^{-1}$',[-1.4,1.4,.2],[-30,30,5],[-20,-10,10,20])
# 同一变量不同层/季节可覆盖：'VET_850' 或 'VET_850_NDJ'（优先级更高）
# ==================================================================
if len(INDEX_VALUES)!=INDEX_END-INDEX_START+1: raise ValueError('请先填写自己的INDEX_VALUES，长度须与INDEX_START/INDEX_END一致')
if SEASON_WEIGHT not in ('equal','days'): raise ValueError('SEASON_WEIGHT只能equal/days')
if BC_MODE not in ('mechanism','direction'): raise ValueError('BC_MODE错误')
if any(s not in ('NDJ','DJF','JFM') for s in SEASONS): raise ValueError('SEASONS错误')
if not 0<DAILY_VALID_FRACTION<=1: raise ValueError('有效日比例必须在(0,1]')
if P_METHOD not in ('iid','hac') or not 0<=HAC_LAGS<=10: raise ValueError('显著性配置错误')
if any(s not in ('slope','mean') for s in PLOT_STATISTICS): raise ValueError('PLOT_STATISTICS错误')
config=dict(index_start=INDEX_START,index_end=INDEX_END,index_values=INDEX_VALUES,index_sign=INDEX_SIGN,
 levels=LEVELS,seasons=SEASONS,calculate=CALCULATE,plot_budget=PLOT_BUDGET,plot_bc=PLOT_BC,
 plot_variables=PLOT_VARIABLES,plot_statistics=PLOT_STATISTICS,bc_mode=BC_MODE,bc_factor=BC_FACTOR,
 season_weight=SEASON_WEIGHT,daily_valid_fraction=DAILY_VALID_FRACTION,min_n=MIN_N,p_method=P_METHOD,hac_lags=HAC_LAGS,
 alpha=ALPHA,mean_contours=MEAN_CONTOURS,extent=EXTENT,dpi=DPI,coastlines=COASTLINES,styles=STYLES,
 font_family=FONT_FAMILY,font_file=FONT_FILE,font_required=FONT_REQUIRED,
 mean_smooth_sigma_deg=MEAN_SMOOTH_SIGMA_DEG,title_size=TITLE_SIZE,mean_contour_interval=MEAN_CONTOUR_INTERVAL,
 budget_root='/data/eddy_temperature_variance_budget/budget',storm_root='/data/eddy_temperature_variance_budget/storm_track',
 output=os.environ['REG_OUTPUT'],figure_output=os.environ['REG_FIGURES'])
with open(sys.argv[1],'w') as f: json.dump(config,f,ensure_ascii=False,indent=2)
PYCONFIG
case "${1:-help}" in
 regress-bc) "$PYTHON" -u "$script_dir/1_regression.py" --config "$config_file" --bc-only ;;
 regress) "$PYTHON" -u "$script_dir/1_regression.py" --config "$config_file" ;;
 budget) "$PYTHON" "$script_dir/2_plot_budget.py" --config "$config_file" ;;
 bc) "$PYTHON" "$script_dir/3_plot_bc_separation.py" --config "$config_file" ;;
 other) "$PYTHON" "$script_dir/4_plot_other_variables.py" --config "$config_file" ;;
 plot)
   if "$PYTHON" -c 'import json,sys;sys.exit(not json.load(open(sys.argv[1]))["plot_budget"])' "$config_file"; then
     "$PYTHON" "$script_dir/2_plot_budget.py" --config "$config_file"
   fi
   if "$PYTHON" -c 'import json,sys;sys.exit(not json.load(open(sys.argv[1]))["plot_bc"])' "$config_file"; then
     "$PYTHON" "$script_dir/3_plot_bc_separation.py" --config "$config_file"
   fi
   "$PYTHON" "$script_dir/4_plot_other_variables.py" --config "$config_file" ;;
 *) echo '用法: bash run0916.sh regress | regress-bc | budget | bc | other | plot' ;;
esac
