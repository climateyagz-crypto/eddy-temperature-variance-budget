"""跨年季节回归。配置仅由 run.sh 写入 JSON；读取原有年度 NetCDF。"""
import argparse
import calendar
import json
from pathlib import Path
import numpy as np
from regression_core import fit_field

SEASONS={'NDJ':[(0,11),(0,12),(1,1)],'DJF':[(0,12),(1,1),(1,2)],'JFM':[(1,1),(1,2),(1,3)]}
LABELS={'NDJ':'ND(0)J(+1)','DJF':'D(0)JF(+1)','JFM':'JFM(+1)'}
BUDGET=['BC','EC','DS','HT','VET','RESI']
BASE=['ut','vt','dtdx','dtdy']
BC_VERSION='Yu2025_Eq4_seasonal_first_v2'
BC_NAMES=['sep_tgr','sep_eddyhflux','sep_tgr_x','sep_tgr_y','sep_eddyhflux_x','sep_eddyhflux_y',
          'BC_NONLINEAR','BC_CLIM','BC_X','BC_Y','BC_RECON','BC_ANOM','BC_DIFF',
          'BC_INPUT_ANOM','BC_SEP_RESIDUAL','BC_MONTHLY_RECON','BC_AVERAGING_DIFF','BC_OPERATOR_DIFF']
# Very loose corruption alarms, NOT clipping thresholds. Values are never auto-deleted.
GROSS_LIMIT={'K2/s':1.e3,'K2':1.e6,'m2/s2':1.e7,'K*m/s':1.e6,'K/m':.1,'s-1':1.}
STAT_KEYS=['index_start','index_end','index_values','index_sign','season_weight',
           'daily_valid_fraction','min_n','p_method','hac_lags','bc_factor','budget_root','storm_root']


def specs(c):
    b=Path(c['budget_root']); st=Path(c['storm_root'])
    result={}
    for k,folder,v in [('BC','baroclinic_conversion','bc'),('EC','EKE_conversion','ec'),('DS','diabatic_source','ds'),('HT','horizontal_transport','ht'),('VET','vertical_transport','vet'),('RESI','residual_term','resi')]:
        result[k]=(str(b/folder/(v+'.monthly.global.1deg.{year}.nc')),v,'monthly','K2/s')
    result['TT']=(str(b/'eddy_T_variance'/'tt.monthly.global.1deg.{year}.BPF_L_2.5_8d.nc'),'tt','monthly','K2')
    result['EKE']=(str(st/'EKE'/'EKE.daymean.global.1deg.{year}.BPF_L_2.5_8d.nc'),'EKE','daily','m2/s2')
    result['VT']=(str(st/'vt'/'vT.daily.global.1deg.{year}.BPF_L_2.5_8d.nc'),'vT','daily','K*m/s')
    result['EGR']=(str(st/'EGR'/'egr.daymean.global.1deg.{year}.nc'),'egr','daily','s-1')
    for k in BASE:
        result[k]=(str(b/'bc_sep'/k/(k+'.monthly.global.1deg.{year}.nc')),k,'monthly','K*m/s' if k in ('ut','vt') else 'K/m')
    return result


def normalized_unit(unit):
    return unit.lower().replace(' ','').replace('**','').replace('^','').replace('*','').replace('−','-')


def unit_factor(actual,expected):
    aliases={'K2/s':['k2/s','k2s-1'], 'K2':['k2'], 'm2/s2':['m2/s2','m2s-2'],
             'K*m/s':['km/s','kms-1','mk/s','mks-1'], 'K/m':['k/m','km-1'], 's-1':['s-1','1/s']}
    a=normalized_unit(actual)
    if a in aliases[expected]: return 1.
    if expected=='s-1' and a in ('day-1','d-1','1/day'): return 1/86400.
    raise ValueError(f'单位不符: {actual!r}; expected {expected}')


def audit_values(a,lat,lon,dates,path,var,level,unit,attributes,extent):
    finite=np.isfinite(a); bad=(finite&(np.abs(a)>GROSS_LIMIT[unit]))|np.isinf(a)
    inside=(lat[:,None]>=extent[2])&(lat[:,None]<=extent[3])&(lon[None,:]>=extent[0])&(lon[None,:]<=extent[1])
    record=dict(path=str(path),variable=var,level=float(level),units=unit,attributes=attributes,
                n_valid=int(finite.sum()),n_nan=int(np.isnan(a).sum()),n_inf=int(np.isinf(a).sum()),
                n_suspicious=int(bad.sum()),n_suspicious_plot_region=int((bad&inside[None]).sum()),
                alarm_limit=GROSS_LIMIT[unit])
    for label,mask in [('global',finite),('plot_region',finite&inside[None])]:
        if mask.any():
            inds=np.unravel_index(np.argmax(np.where(mask,np.abs(a),-1)),a.shape)
            ti,yi,xi=inds
            record[label]=dict(absmax=float(abs(a[inds])),value=float(a[inds]),date=str(dates[ti]),
                               lat=float(lat[yi]),lon=float(lon[xi]))
        else: record[label]=None
    record['examples']=[]
    for ti,yi,xi in np.argwhere(bad)[:6]:
        record['examples'].append(dict(date=str(dates[ti]),lat=float(lat[yi]),lon=float(lon[xi]),value=str(a[ti,yi,xi])))
    return record


def repair_known_polar_fill(a,lat,var,unit,attributes):
    """Only the audited gradient-pole sentinel mismatch; no threshold clipping."""
    if var not in ('dtdx','dtdy') or unit!='K/m': return a,0
    if attributes.get('_FillValue')!='-32767.0': return a,0
    if 'scale_factor' in attributes or 'add_offset' in attributes: return a,0
    poles=np.isclose(np.abs(lat),90.,rtol=0,atol=1.e-8)
    sentinel=float(np.float32(9.96921e36))
    bad=(a==sentinel)&poles[None,:,None]
    n=int(bad.sum())
    if n:
        a=a.copy();a[bad]=np.nan
    return a,n


def read_months(spec,year,level,reference,c,audit_records=None):
    from netCDF4 import Dataset,num2date
    path,var,freq,unit=spec; path=path.format(year=year)
    with Dataset(path) as nc:
        def coord(names):
            for n in names:
                if n in nc.variables: return nc[n]
            raise ValueError(f'{path}: 找不到坐标 {names}')
        pc=coord(('lev','level','pressure_level')); p=np.ma.asarray(pc[:],float).filled(np.nan)
        pu=normalized_unit(getattr(pc,'units','hPa'))
        if pu in ('pa','pascal','pascals'): p/=100
        elif pu not in ('hpa','mb','mbar','millibar','millibars'): raise ValueError(f'{path}: pressure units={pu}')
        hit=np.flatnonzero(np.isclose(p,level,atol=1e-5,rtol=0))
        if len(hit)!=1: raise ValueError(f'{path}: 无唯一 {level} hPa 层')
        yc=coord(('lat','latitude')); xc=coord(('lon','longitude')); tc=coord(('time','valid_time'))
        lat=np.ma.asarray(yc[:],float).filled(np.nan); lon=np.ma.asarray(xc[:],float).filled(np.nan)%360
        iy=np.argsort(lat); ix=np.argsort(lon); lat=lat[iy];lon=lon[ix]
        if not np.isfinite(lat).all() or not np.isfinite(lon).all() or np.any(np.diff(lat)<=0) or np.any(np.diff(lon)<=0):
            raise ValueError(f'{path}: 非法经纬度/重复循环点')
        if reference is not None:
            for a,b in zip((lat,lon),reference):
                if a.shape!=b.shape or not np.allclose(a,b,atol=1e-6,rtol=0): raise ValueError(f'{path}: 水平网格不一致')
        if not hasattr(tc,'units'): raise ValueError(f'{path}: 时间缺少 units')
        dates=num2date(tc[:],tc.units,calendar=getattr(tc,'calendar','standard'))
        v=nc[var]
        expected=(tc.dimensions[0],pc.dimensions[0],yc.dimensions[0],xc.dimensions[0])
        if v.dimensions!=expected: raise ValueError(f'{path}: {var} dims={v.dimensions}, expected={expected}')
        factor=unit_factor(getattr(v,'units',''),unit)
        # 按层读取，避免把整个四维年文件载入内存；netCDF4 自动处理 packing。
        a=np.ma.asarray(v[:,int(hit[0]),:,:],float).filled(np.nan)*factor
        a=a[:,iy,:][:,:,ix]
        attrs={key:repr(getattr(v,key)) for key in ['_FillValue','missing_value','scale_factor','add_offset','valid_range'] if hasattr(v,key)}
        a,n_polar=repair_known_polar_fill(a,lat,var,unit,attrs)
        if n_polar:
            print(f'POLAR_FILL_REPAIRED {path} {var} {level:g}hPa n={n_polar}: exact sentinel at +/-90 only',flush=True)
        rec=audit_values(a,lat,lon,dates,path,var,level,unit,attrs,c.get('extent',[120,260,20,70]))
        rec['n_known_polar_fill_repaired']=n_polar
        if audit_records is not None: audit_records.append(rec)
        if rec['n_suspicious'] and audit_records is None:
            raise ValueError('INPUT_CORRUPTION: '+json.dumps(rec,ensure_ascii=False)+
                             '\n停止：不裁剪、不填零。先运行 --audit-bc 确定污染来源。')
        result=[]
        for month in range(1,13):
            inds=[i for i,d in enumerate(dates) if d.year==year and d.month==month]
            if freq=='monthly':
                if len(inds)!=1: raise ValueError(f'{path}: {year}-{month:02}: 需要一个月记录')
                result.append(a[inds[0]])
            else:
                nday=calendar.monthrange(year,month)[1]
                dd=[dates[i].day for i in inds]
                if dd!=list(range(1,nday+1)): raise ValueError(f'{path}: {year}-{month:02}: 日记录缺失/重复/乱序')
                vals=a[inds]; n=np.isfinite(vals).sum(0)
                avg=np.full(n.shape,np.nan)
                np.divide(np.nansum(vals,0),n,out=avg,where=n>=np.ceil(nday*c['daily_valid_fraction']))
                result.append(avg)
        if any(d.year!=year for d in dates): raise ValueError(f'{path}: 文件包含其他年份')
        return np.stack(result),(lat,lon)


def seasonal(months,weights):
    """Three month axis is 1; require every month, never turn a season into two months."""
    w=np.asarray(weights,float)
    return np.where(np.isfinite(months).all(axis=1),np.sum(months*w[:,:,None,None],axis=1)/w.sum(axis=1)[:,None,None],np.nan)


def sample_mean(a):
    """Mean over index years, using finite samples only; never replace missing values by zero observations."""
    n=np.isfinite(a).sum(axis=0)
    mu=np.full(a.shape[1:],np.nan)
    np.divide(np.nansum(a,axis=0),n,out=mu,where=n>0)
    return mu


def decompose(arr,factor,bc_input,monthly_reconstruction):
    """Yu et al. (2025), p.5 Eq.(4). arr=(4,index_year,lat,lon), already seasonal.

    All climatologies, anomalies and diagnostics use exactly the same valid years.
    Prime in the paper denotes synoptic disturbance, not these interannual anomalies.
    """
    valid=np.isfinite(arr).all(axis=0)&np.isfinite(bc_input)&np.isfinite(monthly_reconstruction)
    a=np.where(valid[None],arr,np.nan)
    observed=np.where(valid,bc_input,np.nan)
    monthly=np.where(valid,monthly_reconstruction,np.nan)
    mu=np.stack([sample_mean(v) for v in a])
    da=a-mu[:,None]
    u,v,gx,gy=a; ub,vb,gxb,gyb=mu; du,dv,dgx,dgy=da
    tgr_x=-factor*ub*dgx; tgr_y=-factor*vb*dgy
    flux_x=-factor*du*gxb; flux_y=-factor*dv*gyb
    recon=-factor*(u*gx+v*gy)
    anomaly=recon-sample_mean(recon)
    raw_interaction=-factor*(du*dgx+dv*dgy)
    nonlinear=raw_interaction-sample_mean(raw_interaction)
    input_anomaly=observed-sample_mean(observed)
    return {'sep_tgr':tgr_x+tgr_y,'sep_eddyhflux':flux_x+flux_y,
            'sep_tgr_x':tgr_x,'sep_tgr_y':tgr_y,
            'sep_eddyhflux_x':flux_x,'sep_eddyhflux_y':flux_y,
            'BC_NONLINEAR':nonlinear,
            'BC_CLIM':np.where(valid,np.broadcast_to(-factor*(ub*gxb+vb*gyb),u.shape),np.nan),
            'BC_X':-factor*u*gx,'BC_Y':-factor*v*gy,
            'BC_RECON':recon,'BC_ANOM':anomaly,'BC_INPUT_ANOM':input_anomaly,
            'BC_SEP_RESIDUAL':input_anomaly-(tgr_x+tgr_y)-(flux_x+flux_y),
            'BC_MONTHLY_RECON':monthly,
            'BC_AVERAGING_DIFF':monthly-recon,
            'BC_OPERATOR_DIFF':observed-monthly,
            'BC_DIFF':recon-observed}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',type=Path,required=True);ap.add_argument('--audit-bc',action='store_true',help='只检查四个基础场和已有BC，不回归、不覆盖结果');ap.add_argument('--bc-only',action='store_true',help='只更新BC分解及诊断，保留其他统计文件');args=ap.parse_args()
    c=json.loads(args.config.read_text()); out=Path(c['output']);out.mkdir(parents=True,exist_ok=True)
    years=np.arange(c['index_start'],c['index_end']+1); x=np.asarray(c['index_values'],float)*c['index_sign']
    if x.shape!=years.shape or not np.isfinite(x).all(): raise ValueError('指数长度必须等于年份数，且不能缺测')
    if len(years)<4 or not 4<=c['min_n']<=len(years): raise ValueError('min_n 必须在 4 与指数长度之间')
    X=np.column_stack((np.ones(len(years)),years-years.mean()))
    x=x-X@np.linalg.lstsq(X,x,rcond=None)[0]
    if np.std(x,ddof=1)<1e-12: raise ValueError('去趋势后指数无有效变化')
    x/=x.std(ddof=1)
    sp=specs(c); grid=None; requested=BC_NAMES if args.bc_only else c['calculate']
    if c['bc_factor']!=1.0:
        raise ValueError('Yu2025 Eq.(4) and supplied BC use coefficient -1; set BC_FACTOR=1.0')
    if args.audit_bc:
        records=[]; errors=[]; reference=None
        actual_years=sorted({int(y+dy) for y in years for ss in c['seasons'] for dy,mo in SEASONS[ss]})
        report=out/'bc_input_audit.json'
        for lev in c['levels']:
            for name in BASE+['BC']:
                for yy in actual_years:
                    try:
                        _,reference=read_months(sp[name],yy,lev,reference,c,audit_records=records)
                        rr=records[-1]
                        if rr['n_suspicious']:
                            print('SUSPECT '+json.dumps(rr,ensure_ascii=False),flush=True)
                    except Exception as exc:
                        err=dict(variable=name,year=yy,level=lev,error=str(exc));errors.append(err)
                        print('READ_ERROR '+json.dumps(err,ensure_ascii=False),flush=True)
                print(f'AUDIT {name} {lev}: done',flush=True)
                report.write_text(json.dumps(dict(records=records,errors=errors),ensure_ascii=False,indent=2))
        nbad=sum(rr['n_suspicious']>0 for rr in records)
        print(f'AUDIT saved {report}; suspicious files/levels={nbad}; read errors={len(errors)}',flush=True)
        if nbad or errors: raise SystemExit(2)
        return
    old_meta={}
    if args.bc_only and (out/'metadata.json').exists():
        old_meta=json.loads((out/'metadata.json').read_text())
        for k in STAT_KEYS:
            if old_meta.get(k)!=c[k]:
                raise ValueError(f'{k} 已改变；请使用 regress 重算全部，不能混合不同配置的结果')
    allowed=set(sp)|set(BC_NAMES)
    if set(requested)-allowed: raise ValueError(f'未知变量 {set(requested)-allowed}')
    need_bc=bool(set(requested)&set(BC_NAMES))
    # Six-term budget always uses the same sample years at every grid point.
    targets=list(dict.fromkeys(requested+(BUDGET if set(requested)&set(BUDGET) else [])))
    needed=[k for k in targets if k in sp]
    if need_bc: needed=list(dict.fromkeys(needed+BASE+['BC']))
    saved=list(old_meta.get('files',[]))
    # Old monthly-first diagnostics must not remain available under the new definition.
    legacy=BC_NAMES+['BC_FLUX','BC_GRAD']
    saved=[f for f in saved if not any(f.startswith(k+'_') for k in legacy)]
    for level in c['levels']:
        for season in c['seasons']:
            pairs=SEASONS[season]
            w=np.array([[calendar.monthrange(int(y+dy),mo)[1] if c['season_weight']=='days' else 1 for dy,mo in pairs] for y in years])
            monthly={}
            for name in needed:
                blocks=[]; cache={}
                for y in years:
                    trip=[]
                    for dy,mo in pairs:
                        yy=int(y+dy)
                        if yy not in cache:
                            cache[yy],grid=read_months(sp[name],yy,level,grid,c)
                        trip.append(cache[yy][mo-1])
                    blocks.append(np.stack(trip))
                    for old in list(cache):
                        if old<=y: del cache[old]
                monthly[name]=np.stack(blocks)
                print(f'Loaded {name} {level:g} hPa {season}',flush=True)
            fields={k:seasonal(v,w) for k,v in monthly.items()}
            # Keep the six budget terms on their own common sample set.
            mask=None
            if set(BUDGET)<=set(fields):
                mask=np.isfinite(np.stack([fields[k] for k in BUDGET])).all(0)
                for k in BUDGET: fields[k]=np.where(mask,fields[k],np.nan)
            if need_bc:
                # First average each basic field over the season. Only then form Eq.(4).
                # Read the original BC independently of the six-term mask so --bc-only
                # and full regress produce identical BC decomposition sample sets.
                bc_input=seasonal(monthly['BC'],w)
                month_product=-c['bc_factor']*(monthly['ut']*monthly['dtdx']+monthly['vt']*monthly['dtdy'])
                monthly_recon=seasonal(month_product,w)
                pieces=decompose(np.stack([fields[k] for k in BASE]),c['bc_factor'],bc_input,monthly_recon)
                fields.update(pieces)
                targets_here=list(dict.fromkeys(targets+BC_NAMES))
            else: targets_here=targets
            for name in targets_here:
                check=fields[name]
                limit=GROSS_LIMIT[sp[name][3]] if name in sp else GROSS_LIMIT['K2/s']
                if np.isinf(check).any() or np.any(np.isfinite(check)&(np.abs(check)>limit)):
                    raise ValueError(f'DERIVED_CORRUPTION {name} {level} {season}: abnormal values before regression; no clipping')
            if need_bc:
                terms=[fields[k] for k in ['BC_ANOM','sep_tgr','sep_eddyhflux','BC_NONLINEAR']]
                error=terms[0]-terms[1]-terms[2]-terms[3]
                # Relative error alone becomes unstable where the physical anomaly is zero.
                scale=sum(np.nan_to_num(np.abs(v),nan=0.) for v in terms)
                ok=np.isfinite(error)
                if np.any(ok&(np.abs(error)>1.e-12+1.e-10*scale)):
                    raise ValueError('BC algebra identity failed before output')
                relative=np.max(np.abs(error[ok])/(1.e-12+scale[ok])) if ok.any() else np.nan
                print('Eq4 scaled closure error:',relative,flush=True)
            for name in targets_here:
                vals=fields.get(name)
                if vals is None: vals=seasonal(monthly[name],w)
                b,pi,ph,n=fit_field(x,vals,years,c['min_n'],c['hac_lags'])
                avg=np.full(vals.shape[1:],np.nan)
                np.divide(np.nansum(vals,0),n,out=avg,where=n>=c['min_n'])
                unit=sp[name][3] if name in sp else 'K2/s'
                path=out/f'{name}_{level:g}_{season}.npz'
                with open(str(path)+'.partial','wb') as f:
                    np.savez_compressed(f,mean=avg,slope=b,p=ph if c['p_method']=='hac' else pi,p_iid=pi,p_hac=ph,n=n,
                                        lat=grid[0],lon=grid[1],years=years,index=x,seasonal_values=vals,units=unit,
                                        bc_definition_version=BC_VERSION if name in BC_NAMES else '')
                Path(str(path)+'.partial').replace(path)
                if path.name not in saved: saved.append(path.name)
            if mask is not None:
                total=sum(fields[k] for k in BUDGET); ok=np.isfinite(total)
                print('Six-term seasonal closure absMax:',np.max(np.abs(total[ok])) if ok.any() else 'no valid data',flush=True)
            if need_bc:
                identity=fields['BC_ANOM']-fields['sep_tgr']-fields['sep_eddyhflux']-fields['BC_NONLINEAR']
                ok=np.isfinite(identity)
                err=np.max(np.abs(identity[ok])) if ok.any() else np.nan
                print('Eq4 seasonal anomaly algebra closure absMax:',err,flush=True)
                ex=c.get('extent',[120,260,20,70])
                region=(grid[0][:,None]>=ex[2])&(grid[0][:,None]<=ex[3])&(grid[1][None,:]>=ex[0])&(grid[1][None,:]<=ex[1])
                for key in ['BC_INPUT_ANOM','sep_tgr','sep_eddyhflux','BC_NONLINEAR','BC_SEP_RESIDUAL','BC_AVERAGING_DIFF','BC_OPERATOR_DIFF']:
                    d=fields[key];ok=np.isfinite(d)
                    print(key+' global RMS:',np.sqrt(np.mean(d[ok]**2)) if ok.any() else 'no valid data',flush=True)
                    regional=ok&region[None]
                    print(key+' plot-region RMS:',np.sqrt(np.mean(d[regional]**2)) if regional.any() else 'no valid data',flush=True)
    meta=dict(c,files=saved,season_labels=LABELS,index_standardized=x.tolist(),model='y = intercept + actual_year_trend + beta * standardized_detrended_index',
              mean_definition='Mean of original seasonal fields on regression-valid years (not detrended).',
              bc_definition_version=BC_VERSION,
              bc_definition='Yu2025 Eq4: first seasonal-average ut/vt/dtdx/dtdy, then seasonal climatology and anomaly; sep_tgr=-F_clim dot G_anom; sep_eddyhflux=-F_anom dot G_clim. BC_ANOM=sep_tgr+sep_eddyhflux+BC_NONLINEAR. BC_NONLINEAR is centered interaction. BC_INPUT_ANOM=sep_tgr+sep_eddyhflux+BC_SEP_RESIDUAL. Numerical and averaging mismatches are stored separately.',
              bc_sample_policy='BC components use common valid years of four seasonal base fields and supplied BC, independently of other budget terms. Full and bc-only agree.',
              p_caveat='Pointwise IID or Bartlett HAC t(n-3) approximation; not field significance; no ENSO control.')
    (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    print('SAVED',out,flush=True)

if __name__=='__main__': main()
