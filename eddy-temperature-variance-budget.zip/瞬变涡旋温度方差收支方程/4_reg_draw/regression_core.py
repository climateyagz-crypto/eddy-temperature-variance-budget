"""共同样本上的趋势控制回归，以及可选的日历年距 HAC 标准误。

模型 y = intercept + trend*year + beta*standardized_index。
HAC 使用 Bartlett 权重，默认滞后 3 年及 n/(n-3) 小样本修正。
p 值使用 t(n-3) 近似；不是精确有限样本检验，不等于论文的有效样本量法。
"""
import numpy as np
from scipy import stats


def fit_field(index, data, years, min_n=30, hac_lags=3):
    x=np.asarray(index,float); t=np.asarray(years,float)
    yy=np.asarray(data,float)
    if x.shape!=t.shape or yy.shape[0]!=len(x):
        raise ValueError('时间长度不匹配')
    if len(np.unique(t))!=len(t) or not np.isfinite(t).all():
        raise ValueError('年份重复或缺测')
    shape=yy.shape[1:]; y=yy.reshape(len(x),-1)
    beta=np.full(y.shape[1],np.nan); pi=beta.copy(); ph=beta.copy()
    counts=np.zeros(y.shape[1],np.int16)
    # 按有效年份模式分组，避免在完整海洋格点重复拟合相同设计矩阵。
    valid=np.isfinite(y)&np.isfinite(x[:,None])
    patterns,group=np.unique(valid.T,axis=0,return_inverse=True)
    for g,ok in enumerate(patterns):
        columns=np.flatnonzero(group==g); n=int(ok.sum()); counts[columns]=n
        if n<max(4,min_n): continue
        tv=t[ok]; xv=x[ok]
        X=np.column_stack((np.ones(n),tv-tv.mean(),xv-xv.mean()))
        if np.linalg.matrix_rank(X)<3: continue
        inv=np.linalg.inv(X.T@X); pinv=inv@X.T; df=n-3
        for first in range(0,len(columns),1024):
            jj=columns[first:first+1024]; Y=y[np.ix_(ok,jj)]
            coef=pinv@Y; resid=Y-X@coef; beta[jj]=coef[2]
            se_iid=np.sqrt(np.sum(resid**2,axis=0)/df*inv[2,2])
            # 只计算 beta 方差所需的投影 score，等价于 sandwich 的 (2,2)。
            z=(X@inv[:,2])[:,None]*resid
            variance=np.sum(z*z,axis=0)
            for lag in range(1,hac_lags+1):
                ia,ib=np.where(tv[:,None]-tv[None,:]==lag)
                variance+=2*(1-lag/(hac_lags+1))*np.sum(z[ia]*z[ib],axis=0)
            se_hac=np.sqrt(np.maximum(variance*n/df,0.))
            for se,dest in [(se_iid,pi),(se_hac,ph)]:
                vals=np.full(len(jj),np.nan)
                good=se>0
                vals[good]=2*stats.t.sf(np.abs(coef[2,good]/se[good]),df)
                vals[(se==0)&(coef[2]!=0)]=0.
                constant=np.ptp(Y,axis=0)==0
                vals[constant]=1.
                dest[jj]=vals
            beta[jj[np.ptp(Y,axis=0)==0]]=0.
    return tuple(a.reshape(shape) for a in (beta,pi,ph,counts))

