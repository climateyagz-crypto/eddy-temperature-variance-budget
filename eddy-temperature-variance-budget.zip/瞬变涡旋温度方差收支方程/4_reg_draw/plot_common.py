"""共享绘图函数；三份绘图入口分别控制收支、BC分解和其他变量。"""
import argparse,json,warnings
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

LABELS={'NDJ':'ND(0)J(+1)','DJF':'D(0)JF(+1)','JFM':'JFM(+1)'}
TITLES={'BC':'Baroclinic conversion','EC':'EKE conversion','DS':'Diabatic source','HT':'Horizontal transport',
        'VET':'Vertical transport','RESI':'Residual','sep_eddyhflux':'Eddy heat flux effect','sep_tgr':'Baroclinic effect',
        'BC_SEP_RESIDUAL':'BC decomposition residual','BC_NONLINEAR':'Centered nonlinear interaction',
        'BC_AVERAGING_DIFF':'Monthly minus seasonal product','BC_OPERATOR_DIFF':'Gradient-operator difference',
        'BC_INPUT_ANOM':'Supplied BC anomaly','BC_ANOM':'Reconstructed BC anomaly',
        'BC_X':'Zonal component','BC_Y':'Meridional component',
        'BC_RECON':'Reconstructed BC','BC_DIFF':'Reconstructed minus supplied BC','TT':"T′²",'VT':"v′T′",'EKE':'EKE','EGR':'EGR'}



def set_fonts(c):
    from matplotlib import font_manager
    family=c.get('font_family','Arial')
    candidates=[]
    supplied=c.get('font_file')
    if supplied:
        supplied_path=Path(supplied).expanduser()
        if not supplied_path.is_absolute(): supplied_path=Path(__file__).resolve().parent/supplied_path
        candidates.append(supplied_path)
    root=Path(__file__).resolve().parent
    for folder in (root/'fonts',root):
        for pattern in ('*.ttf','*.TTF','*.otf','*.OTF'):
            candidates.extend(sorted(folder.glob(pattern)))
    for path in dict.fromkeys(candidates):
        if not path.is_file(): continue
        try:
            prop=font_manager.FontProperties(fname=str(path))
            if prop.get_name().casefold()==family.casefold():
                font_manager.fontManager.addfont(str(path))
        except (OSError,RuntimeError,ValueError) as exc:
            warnings.warn(f'无法加载字体 {path}: {exc}')
    try:
        resolved=font_manager.findfont(font_manager.FontProperties(family=family),fallback_to_default=False)
    except ValueError as exc:
        message=(f'找不到指定字体 {family}。请将真实 Arial.ttf 放到脚本旁 fonts/，'
                 '或修改 run0916.sh 的 FONT_FILE 为服务器有效路径。可同时放 Arial 的粗体和斜体文件。')
        if c.get('font_required',True): raise FileNotFoundError(message) from exc
        warnings.warn(message+' 本次使用 DejaVu Sans。')
        family='DejaVu Sans'
        resolved=font_manager.findfont(font_manager.FontProperties(family=family))
    print(f'FONT: {family}: {resolved}',flush=True)
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':[family],
                         'font.size':12,'axes.unicode_minus':False,'hatch.color':'blue','hatch.linewidth':.6,
                         'mathtext.fontset':'custom','mathtext.rm':family,'mathtext.it':family+':italic',
                         'mathtext.bf':family+':bold','mathtext.cal':family,'pdf.fonttype':42,'ps.fonttype':42})


def smooth_mean_contours(mean,lat,lon,sigma_deg):
    """Display only: normalized Gaussian filter, preserving original missing cells.

    Latitude reflects at domain edges; global longitude wraps. A single angular
    width is applied over land and ocean, before cropping to the map extent.
    This does not mask below-ground pressure surfaces or fix invalid input data.
    """
    from scipy.ndimage import gaussian_filter
    a=np.asarray(mean,float)
    if sigma_deg<0 or not np.isfinite(sigma_deg): raise ValueError('平滑尺度必须为有限非负数')
    if sigma_deg==0: return a.copy()
    spacings=[]
    for coord in (lat,lon):
        delta=np.diff(np.asarray(coord,float))
        if len(delta)==0 or not np.all(delta>0) or not np.allclose(delta,delta[0]):
            raise ValueError('平均线平滑要求等间距且递增的经纬度')
        spacings.append(float(delta[0]))
    sigma=tuple(sigma_deg/d for d in spacings)
    modes=('reflect','wrap' if np.isclose(len(lon)*spacings[1],360) else 'reflect')
    valid=np.isfinite(a)
    numerator=gaussian_filter(np.where(valid,a,0.),sigma,mode=modes,truncate=4.)
    weight=gaussian_filter(valid.astype(float),sigma,mode=modes,truncate=4.)
    result=np.full(a.shape,np.nan)
    np.divide(numerator,weight,out=result,where=valid&(weight>1.e-8))
    return result


def levels_for(lim):
    if len(lim)!=3 or lim[2]<=0 or lim[1]<=lim[0]: raise ValueError('色标格式应为[min,max,step]')
    count=(lim[1]-lim[0])/lim[2]
    if not np.isclose(count,round(count)): raise ValueError('色标步长不能整除范围')
    return np.linspace(lim[0],lim[1],int(round(count))+1)


def get_style(c,name,level,season):
    styles=c['styles']
    return styles.get(f'{name}_{level:g}_{season}',styles.get(f'{name}_{level:g}',styles.get(name,styles['DEFAULT'])))


def mean_levels(mu,region,sty,c):
    values=mu[region&np.isfinite(mu)]
    if not values.size: return np.array([])
    step=sty.get('contour_interval',c.get('mean_contour_interval',3.))
    if step is None:
        ll=np.asarray(sty.get('contours',[]),float)
    else:
        if step<=0: raise ValueError('平均场等值线间隔必须为正数')
        lo=int(np.ceil(values.min()/step));hi=int(np.floor(values.max()/step))
        ll=np.arange(lo,hi+1,dtype=float)*step
    return ll[(ll!=0)&(ll>values.min())&(ll<values.max())]


def draw(c,names,kind,level,season,stat):
    import cartopy.crs as ccrs
    from cartopy.util import add_cyclic_point
    from cartopy.mpl.ticker import LongitudeFormatter,LatitudeFormatter
    out=Path(c['output']); figdir=Path(c['figure_output']);figdir.mkdir(parents=True,exist_ok=True)
    meta=json.loads((out/'metadata.json').read_text())
    # Plot settings may change freely; statistical settings must match the saved calculation.
    for k in ['index_start','index_end','index_values','index_sign','season_weight','daily_valid_fraction','min_n','p_method','hac_lags','bc_factor']:
        if c[k]!=meta[k]: raise ValueError(f'{k} 已更改，请先重新运行 regress，避免给旧回归结果贴新标签')
    set_fonts(c)
    n=len(names); rows,cols=(2,3) if kind=='budget' else (1,n)
    styles=[get_style(c,k,level,season) for k in names]
    limits=[st['regression'] if stat=='slope' else st['mean'] for st in styles]
    signatures=[(tuple(lim),st['multiplier'],st['label'],st.get('cmap','RdBu_r')) for st,lim in zip(styles,limits)]
    shared=len(set(signatures))==1
    # Explicit dimensions in inches: PlateCarree maps keep their natural aspect ratio.
    # No unused subplot height can open a large gap between title and map.
    xmin,xmax,ymin,ymax=c['extent']
    if xmax<=xmin or ymax<=ymin: raise ValueError('EXTENT范围必须递增')
    map_w=5.3; map_h=map_w*(ymax-ymin)/(xmax-xmin)
    left=.66;right=.22;gap=.65;bottom=1.02
    top=.70 if n>1 else .46
    rowgap=.64 if shared else 1.32
    fw=left+right+cols*map_w+(cols-1)*gap
    fh=bottom+top+rows*map_h+(rows-1)*rowgap
    fig=plt.figure(figsize=(fw,fh))
    axs=[]
    for j in range(n):
        rr,cc=divmod(j,cols)
        yy=bottom+(rows-1-rr)*(map_h+rowgap)
        axs.append(fig.add_axes([(left+cc*(map_w+gap))/fw,yy/fh,map_w/fw,map_h/fh],
                               projection=ccrs.PlateCarree(central_longitude=180)))
    suffix="T′² budget" if kind=='budget' else ('BC Separation Component' if kind=='bc' else TITLES.get(names[0],names[0]))
    # One ordinary space between title elements. Single panels do not repeat a subtitle.
    title_y=(fh-top+(.38 if n>1 else .10))/fh
    fig.text((left+cols*map_w/2+(cols-1)*gap/2)/fw,title_y,
             f'{LABELS[season]} {level:g}-hPa {suffix}',ha='center',va='bottom',
             fontsize=c.get('title_size',18),fontweight='bold')
    color_mappables=[]
    for i,name in enumerate(names):
        path=out/f'{name}_{level:g}_{season}.npz'
        if path.name not in meta['files']:
            raise ValueError(f'{path.name} 不在本次回归结果中；请加入 CALCULATE 并重新 regress')
        with np.load(path) as r:
            if name.startswith('sep_') or name.startswith('BC_'):
                if str(r.get('bc_definition_version',''))!='Yu2025_Eq4_seasonal_first_v2':
                    raise ValueError(f'{path.name} 是旧BC定义；请先运行 bash run0916.sh regress-bc')
            lat=r['lat'];lon=r['lon'];data=r[stat];mean=r['mean'];p=r['p']
        sty=styles[i];mult=sty['multiplier'];values=data*mult
        levels=levels_for(limits[i])
        ax=axs[i]
        if values.shape!=(len(lat),len(lon)): raise ValueError(f'{name}: 数据与坐标形状不符')
        region=(lat[:,None]>=ymin)&(lat[:,None]<=ymax)&(lon[None,:]>=xmin)&(lon[None,:]<=xmax)
        use_cyclic=len(lon)>1 and np.allclose(np.diff(lon),np.diff(lon)[0]) and np.isclose(len(lon)*np.diff(lon)[0],360)
        def cyc(a): return add_cyclic_point(a,coord=lon) if use_cyclic else (a,lon)
        dd,ll=cyc(values)
        cf=ax.contourf(ll,lat,np.ma.masked_invalid(dd),levels=levels,cmap=sty.get('cmap','RdBu_r'),extend='both',transform=ccrs.PlateCarree())
        if stat=='slope':
            pp,_=cyc(p);sig=np.where(np.isfinite(pp)&(pp<c['alpha']),1.,np.nan)
            if np.isfinite(sig).any():
                hatch=ax.contourf(ll,lat,np.ma.masked_invalid(sig),levels=[.5,1.5],colors='none',hatches=['////'],transform=ccrs.PlateCarree(),zorder=11)
                # Matplotlib older versions expose collections; new ones expose the contour set.
                artists=hatch.collections if hasattr(hatch,'collections') else [hatch]
                for artist in artists:
                    artist.set_edgecolor('blue');artist.set_linewidth(0.)
            if c['mean_contours']:
                smoothed=smooth_mean_contours(mean*mult,lat,lon,sty.get('mean_smooth_sigma_deg',c.get('mean_smooth_sigma_deg',1.)))
                ml=mean_levels(smoothed,region,sty,c)
                mu,_=cyc(smoothed)
                if ml.size:
                    # Label placement must use the visible region, not the entire globe.
                    yi=np.flatnonzero((lat>=ymin)&(lat<=ymax))
                    xi=np.flatnonzero((ll>=xmin)&(ll<=xmax))
                    if len(yi)<2 or len(xi)<2: raise ValueError('绘图区内网格点不足以画平均场等值线')
                    cs=ax.contour(ll[xi],lat[yi],np.ma.masked_invalid(mu[np.ix_(yi,xi)]),levels=ml,colors='black',linewidths=1.,transform=ccrs.PlateCarree(),zorder=12)
                    ax.clabel(cs,inline=True,fontsize=10,fmt='%g')
        ax.set_extent(c['extent'],crs=ccrs.PlateCarree())
        if c['coastlines']: ax.coastlines(resolution='110m',linewidth=.8,color='black',zorder=10)
        ax.set_xticks(np.arange(c['extent'][0],c['extent'][1]+.1,30),crs=ccrs.PlateCarree())
        ax.set_yticks(np.arange(c['extent'][2],c['extent'][3]+.1,15),crs=ccrs.PlateCarree())
        ax.xaxis.set_major_formatter(LongitudeFormatter()); ax.yaxis.set_major_formatter(LatitudeFormatter())
        ax.tick_params(labelsize=11,length=3,width=.8,pad=3)
        if n>1:
            ax.set_title(f'({chr(97+i)}) {TITLES.get(name,name)}',fontsize=13,fontweight='bold',pad=7,loc='left')
        color_mappables.append(cf)
        ok=region&np.isfinite(values)
        lim=limits[i]
        if ok.any(): print(f'{name} {level:g} {season} {stat}: color saturation={np.mean((values[ok]<lim[0])|(values[ok]>lim[1])):.1%}')
    # Shared horizontal colorbar for equal units/ranges; independent bars only for explicit overrides.
    color_groups=[(0,styles[0],limits[0])] if shared else [(i,styles[i],limits[i]) for i in range(n)]
    for i,sty,lim in color_groups:
        if shared:
            width=min(.50*fw,7.2) if n>1 else .78*map_w
            xx=(fw-width)/2; yy=.47
        else:
            rr,cc=divmod(i,cols);width=.80*map_w
            xx=left+cc*(map_w+gap)+(map_w-width)/2
            yy=bottom+(rows-1-rr)*(map_h+rowgap)-.57
        cbax=fig.add_axes([xx/fw,yy/fh,width/fw,.15/fh])
        cb=fig.colorbar(color_mappables[i],cax=cbax,orientation='horizontal',ticks=np.linspace(lim[0],lim[1],5))
        cb.ax.tick_params(labelsize=11,length=3,width=.8,pad=3)
        cb.outline.set_linewidth(.7)
        cb.ax.text(1.09,.5,sty['label'],transform=cb.ax.transAxes,
                   ha='left',va='center',fontsize=12,clip_on=False)
    filename=f'{kind}_{names[0] if kind=="other" else c["bc_mode"] if kind=="bc" else "six_terms"}_{level:g}_{season}_{stat}.png'
    fig.savefig(figdir/filename,dpi=c['dpi'],bbox_inches='tight',pad_inches=.08);plt.close(fig)
    print('SAVED',figdir/filename)


def main(kind):
    ap=argparse.ArgumentParser(); ap.add_argument('--config',type=Path,required=True);a=ap.parse_args()
    c=json.loads(a.config.read_text())
    names= ['BC','EC','DS','HT','VET','RESI'] if kind=='budget' else (['sep_tgr','sep_eddyhflux'] if c['bc_mode']=='mechanism' else ['BC_X','BC_Y']) if kind=='bc' else c['plot_variables']
    groups=[names] if kind!='other' else [[k] for k in names]
    for level in c['levels']:
        for season in c['seasons']:
            for stat in c['plot_statistics']:
                for group in groups: draw(c,group,kind,level,season,stat)
