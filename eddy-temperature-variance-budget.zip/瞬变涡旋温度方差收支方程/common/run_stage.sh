#!/usr/bin/env bash
set -euo pipefail
stage_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
source "$stage_root/config.sh"
if ! [[ "$START_YEAR" =~ ^[0-9]{4}$ && "$END_YEAR" =~ ^[0-9]{4}$ ]]; then
  echo '年份必须为四位整数'; exit 2
fi
if (( START_YEAR < 1980 || END_YEAR > 2024 || START_YEAR > END_YEAR )); then
  echo '当前实现需要完整月边界数据，年份范围须在1980--2024内（默认1982--2023）'; exit 2
fi
run_ncl() {
  local script="$1"
  local log="$stage_root/logs/${script//\//_}.log"
  mkdir -p "$stage_root/logs"
  command -v ncl >/dev/null || { echo '请激活 NCL 环境'; exit 1; }
  (cd "$stage_root"; ncl -Q "start_year=$START_YEAR" "end_year=$END_YEAR" "$script") 2>&1 | tee "$log"
  if grep -Eiq 'fatal:|BUDGET_FATAL' "$log" || ! grep -q 'BUDGET_DONE:' "$log"; then
    echo "STOP: $log"; exit 1
  fi
}

